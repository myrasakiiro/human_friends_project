package registry;

public class Camel extends PackAnimal {
    public Camel(String name, String birthDate) {
        super(name, birthDate);
    }

    public void walkInDesert() {
        System.out.println(getName() + " идёт по пустыне...");
    }
}
