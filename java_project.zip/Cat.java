package registry;

public class Cat extends PetAnimal {
    public Cat(String name, String birthDate) {
        super(name, birthDate);
    }

    public void meow() {
        System.out.println(getName() + " говорит: Мяу!");
    }
}