package registry;

public class Counter implements AutoCloseable {
    private static int count = 0;
    private boolean closed = false;

    public void add() {
        if (closed) {
            throw new IllegalStateException("Ресурс закрыт! Нельзя использовать счётчик.");
        }
        count++;
    }

    public static int getCount() {
        return count;
    }

    @Override
    public void close() {
        closed = true;
        System.out.println("Счётчик закрыт. Всего животных заведено: " + count);
    }
}
