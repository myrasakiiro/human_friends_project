package registry;

public class Dog extends PetAnimal {
    public Dog(String name, String birthDate) {
        super(name, birthDate);
    }

    public void bark() {
        System.out.println(getName() + " говорит: Гав-гав!");
    }
}