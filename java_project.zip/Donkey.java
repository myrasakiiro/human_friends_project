package registry;

public class Donkey extends PackAnimal {
    public Donkey(String name, String birthDate) {
        super(name, birthDate);
    }

    public void carryLoad() {
        System.out.println(getName() + " несёт груз.");
    }
}
