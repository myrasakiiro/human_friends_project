package registry;

public class Hamster extends PetAnimal {
    public Hamster(String name, String birthDate) {
        super(name, birthDate);
    }

    public void spinWheel() {
        System.out.println(getName() + " крутит колесо!");
    }
}
