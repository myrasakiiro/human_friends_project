package registry;

public class Horse extends PackAnimal {
    public Horse(String name, String birthDate) {
        super(name, birthDate);
    }

    public void trot() {
        System.out.println(getName() + " идёт рысью!");
    }
}
