package registry;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Registry registry = new Registry();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("\n--- Реестр животных ---");
            System.out.println("1. Завести новое животное");
            System.out.println("2. Показать команды животного");
            System.out.println("3. Обучить животное команде");
            System.out.println("4. Показать всех животных");
            System.out.println("0. Выход");
            System.out.print("Выберите действие: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    System.out.print("Введите имя животного: ");
                    String name = scanner.nextLine();
                    System.out.print("Введите дату рождения (гггг-мм-дд): ");
                    String birthDate = scanner.nextLine();
                    System.out.print("Тип (dog, cat, hamster, horse, camel, donkey): ");
                    String type = scanner.nextLine().toLowerCase();

                    Animal animal = switch (type) {
                        case "dog" -> new Dog(name, birthDate);
                        case "cat" -> new Cat(name, birthDate);
                        case "hamster" -> new Hamster(name, birthDate);
                        case "horse" -> new Horse(name, birthDate);
                        case "camel" -> new Camel(name, birthDate);
                        case "donkey" -> new Donkey(name, birthDate);
                        default -> null;
                    };

                    if (animal != null) {
                        Counter counter = null;
                        try {
                            counter = new Counter();
                            registry.addAnimal(animal);
                            counter.add();
                        } catch (Exception e) {
                            System.out.println("Ошибка при работе со счётчиком: " + e.getMessage());
                        } finally {
                            if (counter != null) {
                                try {
                                    counter.close();
                                    // Попытка использовать после закрытия — вызовет исключение
                                    counter.add();
                                } catch (Exception e) {
                                    System.out.println("Поймано исключение после закрытия: " + e.getMessage());
                                }
                            }
                        }
                    } else {
                        System.out.println("Неизвестный тип животного.");
                    }
                    
                    break;

                case "2":
                    for (Animal a : registry.getAllAnimals()) {
                        System.out.println("- " + a.getName());
                    }
                    System.out.print("Введите имя животного для показа команд: ");
                    String showName = scanner.nextLine();
                    registry.getAllAnimals().stream()
                        .filter(a -> a.getName().equalsIgnoreCase(showName))
                        .findFirst()
                        .ifPresentOrElse(
                            registry::showCommands,
                            () -> System.out.println("Животное не найдено.")
                        );
                    break;

                case "3":
                    for (Animal a : registry.getAllAnimals()) {
                        System.out.println("- " + a.getName());
                    }
                    System.out.print("Введите имя животного: ");
                    String teachName = scanner.nextLine();
                    System.out.print("Введите команду: ");
                    String command = scanner.nextLine();
                    registry.getAllAnimals().stream()
                        .filter(a -> a.getName().equalsIgnoreCase(teachName))
                        .findFirst()
                        .ifPresentOrElse(
                            a -> registry.teachCommand(a, command),
                            () -> System.out.println("Животное не найдено.")
                        );
                    break;

                case "4":
                    for (Animal a : registry.getAllAnimals()) {
                        a.showInfo();
                    }
                    break;

                case "0":
                    running = false;
                    System.out.println("Выход...");
                    break;

                default:
                    System.out.println("Неверный выбор.");
            }
        }

        scanner.close();
    }
}
