package registry;

public class PetAnimal extends Animal {
    public PetAnimal(String name, String birthDate) {
        super(name, birthDate);
    }
}