package registry;

import java.util.*;

public class Registry {
    private Map<Animal, List<String>> animals = new HashMap<>();

    public void addAnimal(Animal animal) {
        animals.put(animal, new ArrayList<>());
        System.out.println("Животное добавлено: " + animal.getName());
    }

    public void teachCommand(Animal animal, String command) {
        List<String> commands = animals.get(animal);
        if (commands != null) {
            commands.add(command);
            System.out.println(animal.getName() + " выучил команду: " + command);
        }
    }

    public void showCommands(Animal animal) {
        List<String> commands = animals.get(animal);
        if (commands != null && !commands.isEmpty()) {
            System.out.println("Команды " + animal.getName() + ": " + commands);
        } else {
            System.out.println(animal.getName() + " не знает ни одной команды.");
        }
    }

    public List<Animal> getAllAnimals() {
        return new ArrayList<>(animals.keySet());
    }
}
